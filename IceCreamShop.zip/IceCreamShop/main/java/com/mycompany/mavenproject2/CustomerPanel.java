
package com.mycompany.mavenproject2;


import java.awt.HeadlessException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;




public class CustomerPanel extends javax.swing.JFrame {

    DefaultTableModel model = null;
    public CustomerPanel() {
        initComponents();
      
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            PreparedStatement ps = con.prepareStatement("Select * from product");
            ResultSet rs =ps.executeQuery();
            com.mysql.cj.jdbc.result.ResultSetMetaData rsmd=(com.mysql.cj.jdbc.result.ResultSetMetaData) rs.getMetaData();
            int n=rsmd.getColumnCount();
            model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);
            
            while(rs.next()){
           
                Vector v = new Vector();
                for(int i=1;i<=n;i++)
                {
                    v.add(rs.getInt("ProductID"));
                    v.add(rs.getString("ProductName"));
                    v.add(rs.getString("Category"));
                    v.add(rs.getInt("Quantity"));
                    v.add(rs.getInt("Price"));
                    v.add(rs.getString("Discription"));
                    v.add(rs.getBytes("Image"));
                    
                   
                    
                }
                    model.addRow(v);
           }
            
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void search(String str){
        
         model = (DefaultTableModel) jTable1.getModel();
         TableRowSorter<DefaultTableModel> trs = new TableRowSorter<>(model);
         jTable1.setRowSorter(trs);
         trs.setRowFilter(RowFilter.regexFilter(str));
    }
    
    public void pname(){
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jTabbedPane4 = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jDateChooser2 = new com.toedter.calendar.JDateChooser();
        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane5 = new javax.swing.JTabbedPane();
        jPanel7 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel15 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jButton8 = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jTabbedPane6 = new javax.swing.JTabbedPane();
        jPanel9 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jTextField7 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jSlider1 = new javax.swing.JSlider();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jTextField10 = new javax.swing.JTextField();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 255));

        jTabbedPane1.setBackground(new java.awt.Color(204, 204, 255));
        jTabbedPane1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        jTabbedPane2.setBackground(new java.awt.Color(255, 204, 204));
        jTabbedPane2.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        jTabbedPane2.setToolTipText("Welcome");
        jTabbedPane2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel4.setLayout(null);

        jLabel16.setIcon(new javax.swing.ImageIcon("C:\\Users\\sanjo\\Downloads\\pikrepo (3).jpg")); // NOI18N
        jLabel16.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Welcome", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Script", 1, 18), new java.awt.Color(255, 255, 0))); // NOI18N
        jPanel4.add(jLabel16);
        jLabel16.setBounds(3, 6, 720, 400);

        jTabbedPane2.addTab("Welcome", jPanel4);

        jTabbedPane1.addTab("Home", jTabbedPane2);

        jTabbedPane4.setBackground(new java.awt.Color(153, 255, 255));
        jTabbedPane4.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        jTabbedPane4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jPanel1.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 255));
        jLabel2.setText("OrderID :");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(50, 70, 80, 20);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 255));
        jLabel3.setText("ProductID :");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(50, 120, 90, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 255));
        jLabel4.setText("Quantity : ");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(50, 170, 80, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 255));
        jLabel5.setText("Address : ");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(360, 170, 90, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 255));
        jLabel6.setText("PhoneNo :");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(360, 70, 80, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 255));
        jLabel7.setText("Date :");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(360, 120, 70, 20);

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 51, 255));
        jLabel17.setText("Price : ");
        jPanel1.add(jLabel17);
        jLabel17.setBounds(50, 220, 70, 20);

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField1);
        jTextField1.setBounds(150, 70, 170, 25);

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField2);
        jTextField2.setBounds(150, 120, 170, 25);
        jPanel1.add(jTextField3);
        jTextField3.setBounds(150, 170, 170, 25);

        jTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField4ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField4);
        jTextField4.setBounds(450, 70, 170, 25);
        jPanel1.add(jTextField5);
        jTextField5.setBounds(150, 270, 170, 23);

        jTextField6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField6ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField6);
        jTextField6.setBounds(150, 220, 100, 25);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(450, 170, 180, 86);

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-submit-for-approval-24.png"))); // NOI18N
        jButton1.setText("Order");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(40, 333, 100, 30);

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-erase-24_2.png"))); // NOI18N
        jButton2.setText("Clear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(160, 333, 100, 30);

        jButton3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-rupee-24.png"))); // NOI18N
        jButton3.setText("Get Price");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3);
        jButton3.setBounds(260, 220, 130, 25);
        jPanel1.add(jDateChooser2);
        jDateChooser2.setBounds(450, 120, 170, 22);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 255));
        jLabel8.setText("CustomerID :");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(50, 270, 90, 20);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\sanjo\\Downloads\\pexels-jill-wellington-461189.jpg")); // NOI18N
        jLabel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Make Order", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Script", 1, 14), new java.awt.Color(255, 255, 51))); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 710, 410);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 708, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 407, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane4.addTab("Make Order", jPanel5);

        jTabbedPane1.addTab("Order", jTabbedPane4);

        jTabbedPane5.setBackground(new java.awt.Color(102, 255, 255));
        jTabbedPane5.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        jTabbedPane5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jPanel3.setLayout(null);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ProductID", "ProductName", "Category", "Quantity", "Price", "Description", "Image"
            }
        ));
        jScrollPane3.setViewportView(jTable1);

        jPanel3.add(jScrollPane3);
        jScrollPane3.setBounds(10, 70, 680, 330);

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-search-24.png"))); // NOI18N
        jLabel15.setText("Search Product : ");
        jPanel3.add(jLabel15);
        jLabel15.setBounds(50, 30, 150, 30);

        jTextField9.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField9KeyReleased(evt);
            }
        });
        jPanel3.add(jTextField9);
        jTextField9.setBounds(210, 30, 240, 30);

        jButton8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-reset-23.png"))); // NOI18N
        jButton8.setText("Refresh");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel3.add(jButton8);
        jButton8.setBounds(540, 30, 110, 30);

        jLabel14.setBackground(new java.awt.Color(204, 255, 255));
        jLabel14.setForeground(new java.awt.Color(204, 255, 255));
        jLabel14.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "View IceCream", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Script", 0, 14), new java.awt.Color(255, 0, 255))); // NOI18N
        jLabel14.setIconTextGap(6);
        jPanel3.add(jLabel14);
        jLabel14.setBounds(0, 0, 690, 400);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 684, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 401, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane5.addTab("View IceCream", jPanel7);

        jTabbedPane1.addTab("View IceCream", jTabbedPane5);

        jTabbedPane6.setBackground(new java.awt.Color(102, 255, 255));
        jTabbedPane6.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        jTabbedPane6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jPanel2.setLayout(null);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 255, 255));
        jLabel10.setText("CustomerID : ");
        jPanel2.add(jLabel10);
        jLabel10.setBounds(100, 60, 90, 20);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 255, 255));
        jLabel11.setText("Date : ");
        jPanel2.add(jLabel11);
        jLabel11.setBounds(100, 100, 90, 20);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 255, 255));
        jLabel12.setText("Rate : ");
        jPanel2.add(jLabel12);
        jLabel12.setBounds(100, 140, 90, 20);

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 255, 255));
        jLabel13.setText("Comment : ");
        jPanel2.add(jLabel13);
        jLabel13.setBounds(100, 180, 90, 20);
        jPanel2.add(jTextField7);
        jTextField7.setBounds(210, 60, 170, 25);

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        jPanel2.add(jScrollPane2);
        jScrollPane2.setBounds(210, 180, 250, 86);

        jSlider1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jSlider1MouseClicked(evt);
            }
        });
        jPanel2.add(jSlider1);
        jSlider1.setBounds(210, 140, 170, 20);

        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-email-send-24.png"))); // NOI18N
        jButton4.setText("Send");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton4);
        jButton4.setBounds(100, 300, 100, 30);

        jButton5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-erase-24.png"))); // NOI18N
        jButton5.setText("Clear");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5);
        jButton5.setBounds(230, 300, 100, 30);

        jButton6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-logout-24.png"))); // NOI18N
        jButton6.setText("Logout");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton6);
        jButton6.setBounds(360, 300, 110, 30);
        jPanel2.add(jTextField10);
        jTextField10.setBounds(400, 140, 40, 22);
        jPanel2.add(jDateChooser1);
        jDateChooser1.setBounds(210, 100, 170, 23);

        jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\sanjo\\Downloads\\pexels-valeria-boltneva-1893566.jpg")); // NOI18N
        jLabel9.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "FeedBack", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Script", 1, 18), new java.awt.Color(255, 255, 51))); // NOI18N
        jPanel2.add(jLabel9);
        jLabel9.setBounds(0, 0, 650, 400);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 654, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 401, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane6.addTab("Feedback & Logout", jPanel9);

        jTabbedPane1.addTab("Feedback And Logout", jTabbedPane6);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        Login l = new Login();
                l.setVisible(true);
                this.dispose();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
        jTextField6.setText("");
        jTextArea1.setText("");
        jDateChooser2.setDate(null);
               
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jSlider1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jSlider1MouseClicked
        int number1;
        
        number1 = jSlider1.getValue();
        jTextField10.setText(Integer.toString(number1));
    }//GEN-LAST:event_jSlider1MouseClicked

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        
        String CustID = jTextField7.getText();
        Date date =jDateChooser1.getDate(); 
        SimpleDateFormat odf = new SimpleDateFormat("yyyy-MM-dd");
        String ddate =odf.format(date);
        String rate = jTextField10.getText();
        String cmt = jTextArea2.getText();
        
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://Localhost:3306/icecreamshop","root","root");
            PreparedStatement ps =con.prepareStatement("insert into customerfeedback(CustomerID,Date,Rate,Comment)value(?,?,?,?)");
            
            ps.setString(1, CustID);
            ps.setString(2, ddate);
            ps.setString(3, rate);
            ps.setString(4, cmt);
            
            int row = ps.executeUpdate();
            if(row > 0)
            {
                 JOptionPane.showMessageDialog(this, "Feedback send");
            }
            else
            {
                 JOptionPane.showMessageDialog(this, "Feedback not send");
            }
            
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CustomerPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        int CustID =Integer.parseInt (jTextField5.getText());
        int PID =Integer.parseInt (jTextField2.getText());
        
           try
        {
           Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root")) {
                Statement obj=(Statement) con.createStatement();
                ResultSet rs2=obj.executeQuery("select UserID from Customer where UserID='"+CustID+"'");
                if(rs2.next()){
               
        
        try
        {
//           Class.forName("com.mysql.cj.jdbc.Driver");
//            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root")) {
//              Statement obj=(Statement) con.createStatement();
                ResultSet rs=obj.executeQuery("select ProductID from Product where ProductID='"+PID+"'");
                if(rs.next()){
                   
                    int OrderID =Integer.parseInt( jTextField1.getText());
                    int ProductID =Integer.parseInt( jTextField2.getText());
                    int CustomerID =Integer.parseInt( jTextField5.getText());
                    Date date =jDateChooser2.getDate(); 
                    SimpleDateFormat odf = new SimpleDateFormat("yyyy-MM-dd");
                    String ddate =odf.format(date);
                    int Quantity =Integer.parseInt( jTextField3.getText());
                    String Phone = jTextField4.getText();
                    String Address = jTextArea1.getText();
                    int price =Integer.parseInt( jTextField6.getText());
                   
        
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            PreparedStatement ps =con.prepareStatement("insert into orders(OrderID,ProductID,CustomerID,Quantity,Date,Phone,Address)value(?,?,?,?,?,?,?)");
            
            ps.setInt(1, OrderID);
            ps.setInt(2, ProductID);
            ps.setInt(3, CustomerID);
            ps.setInt(4, Quantity);
            ps.setString(5, ddate);
            ps.setString(6, Phone);
            ps.setString(7, Address);
            
            int row = ps.executeUpdate();
            if(row > 0)
            {
                 JOptionPane.showMessageDialog(this, "Order Placed");
                 
                 Reciept r = new Reciept();
                 r.getorderid(OrderID, ProductID, CustomerID, Quantity, ddate, Address);
                 r.sum(Quantity, price);
                 r.setVisible(true);
                 this.dispose();
                 
                  
                  try{
                       Class.forName("com.mysql.cj.jdbc.Driver");
                       Connection con1 =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
                       Statement obj1=(Statement) con1.createStatement();
                       ResultSet rs1=obj1.executeQuery("select ProductName from Product where ProductID='"+PID+"';");
                       if(rs1.next()){
                
                         
                         r.jLabel28.setText(rs1.getString(1));
                        
                
                 }
  
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
                 
             }
            else
            {
                 JOptionPane.showMessageDialog(this, "Order Not Placed");
            }
            
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CustomerPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
                }
                else
                {
                    JOptionPane.showMessageDialog(this,"ProductID Not Found","Error",JOptionPane.ERROR_MESSAGE);
                }
//            }
        }catch(HeadlessException | SQLException e){JOptionPane.showMessageDialog(this,e.getMessage());}
       
     }
     else
     {
        JOptionPane.showMessageDialog(this,"CustomerID Not Found","Error",JOptionPane.ERROR_MESSAGE);
                }
            }
        }catch(HeadlessException | ClassNotFoundException | SQLException e){JOptionPane.showMessageDialog(this,e.getMessage());}
           
       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTextField9KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField9KeyReleased
        
        String str = jTextField9.getText();
        search(str);
    }//GEN-LAST:event_jTextField9KeyReleased

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        
          try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            PreparedStatement ps = con.prepareStatement("Select * from product");
            ResultSet rs =ps.executeQuery();
            com.mysql.cj.jdbc.result.ResultSetMetaData rsmd=(com.mysql.cj.jdbc.result.ResultSetMetaData) rs.getMetaData();
            int n=rsmd.getColumnCount();
            model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);
            
            while(rs.next()){
           
                Vector v = new Vector();
                for(int i=1;i<=n;i++)
                {
                    v.add(rs.getInt("ProductID"));
                    v.add(rs.getString("ProductName"));
                    v.add(rs.getString("Category"));
                    v.add(rs.getInt("Quantity"));
                    v.add(rs.getInt("Price"));
                    v.add(rs.getString("Discription"));
                    v.add(rs.getBytes("Image"));
                    
                   
                    
                }
                    model.addRow(v);
           }
            
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
         jTable1.setAutoCreateRowSorter(true);
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        
        jTextField7.setText("");
        jTextField10.setText("");
        jTextArea2.setText("");
        jDateChooser1.setDate(null);
        
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        
           String pid = jTextField2.getText();
          
         try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            Statement obj=(Statement) con.createStatement();
            ResultSet rs=obj.executeQuery("select Price from Product where ProductID='"+pid+"';");
            if(rs.next()){
                
                jTextField6.setText(rs.getString(1));
                
                 }
  
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField4ActionPerformed
        
        String Phone=jTextField4.getText();
      
        if(!Pattern.matches("^\\d{10}$",Phone))
        {
           JOptionPane.showMessageDialog(this, "Please Enter Valid Number");         
            
        }
    }//GEN-LAST:event_jTextField4ActionPerformed

    private void jTextField6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField6ActionPerformed
        
    }//GEN-LAST:event_jTextField6ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
          
//          try{
//            Class.forName("com.mysql.cj.jdbc.Driver");
//            ResultSet rs3=obj.executeQuery("select Max(OrderID) from Orders");
//            rs3.next();
//            
//            rs3.getString("Max(OrderID)");
//            
//            if(rs3.getString("Max(OrderID)")==null)
//            {
//                JOptionPane.showMessageDialog(this,"100");
//            }
//            else
//            {
//                Long id = Long.parseLong(rs3.getString("Max(OrderID)").substring(2,rs3.getString("Max(OrderID)").length()));
//                JOptionPane.showMessageDialog(this,"101"+String.format("%03d",id));
//            }
//               
//  
//        }catch (ClassNotFoundException | SQLException ex) {
//            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
//        }
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
         
    }//GEN-LAST:event_jTextField2ActionPerformed
      
     public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerPanel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton8;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private com.toedter.calendar.JDateChooser jDateChooser2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSlider jSlider1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane4;
    private javax.swing.JTabbedPane jTabbedPane5;
    private javax.swing.JTabbedPane jTabbedPane6;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
