
package com.mycompany.mavenproject2;


import com.mysql.cj.jdbc.result.ResultSetMetaData;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;



public final class AdminPanel extends javax.swing.JFrame {
    
    DefaultTableModel model = null;
    
    public AdminPanel() {
        initComponents();
        getdata();
        feedback();
        product();
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            PreparedStatement ps = con.prepareStatement("Select * from orders");
            ResultSet rs =ps.executeQuery();
            ResultSetMetaData rsmd=(ResultSetMetaData) rs.getMetaData();
            int n=rsmd.getColumnCount();
            model = (DefaultTableModel) jTable2.getModel();
            model.setRowCount(0);
            
            while(rs.next()){
                
                Vector v = new Vector();
                for(int i=1;i<=n;i++)
                {
                    v.add(rs.getString("OrderID"));
                    v.add(rs.getString("ProductID"));
                    v.add(rs.getString("Quantity"));
                    v.add(rs.getString("CustomerID"));
                    v.add(rs.getString("Date"));
                    v.add(rs.getString("Phone"));
                    v.add(rs.getString("Address"));
                }
                    model.addRow(v);
           }
            
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
     
    public void getdata()
    {
      try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            PreparedStatement ps = con.prepareStatement("Select * from Customer");
            ResultSet rs =ps.executeQuery();
            ResultSetMetaData rsmd=(ResultSetMetaData) rs.getMetaData();
            int n=rsmd.getColumnCount();
            model = (DefaultTableModel) jTable3.getModel();
            model.setRowCount(0);
            
            while(rs.next()){
                
                Vector v = new Vector();
                for(int i=1;i<=n;i++)
                {
                    v.add(rs.getString("UserID"));
                    v.add(rs.getString("UserName"));
                    v.add(rs.getString("Date"));
                    v.add(rs.getString("Phone"));
                    v.add(rs.getString("Address"));
                   
                    
                }
                    model.addRow(v);
           }
            
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void feedback()
    {
         try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            PreparedStatement ps = con.prepareStatement("Select * from Customerfeedback");
            ResultSet rs =ps.executeQuery();
            ResultSetMetaData rsmd=(ResultSetMetaData) rs.getMetaData();
            int n=rsmd.getColumnCount();
            model = (DefaultTableModel) jTable4.getModel();
            model.setRowCount(0);
            
            while(rs.next()){
                
                Vector v = new Vector();
                for(int i=1;i<=n;i++)
                {
                    v.add(rs.getString("CustomerID"));
                    v.add(rs.getString("Date"));
                    v.add(rs.getString("Rate"));
                    v.add(rs.getString("Comment"));
                   
                    
                }
                    model.addRow(v);
           }
            
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void product()
    {
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            PreparedStatement ps = con.prepareStatement("Select * from product");
            ResultSet rs =ps.executeQuery();
            ResultSetMetaData rsmd=(ResultSetMetaData) rs.getMetaData();
            int n=rsmd.getColumnCount();
            model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);
            
            while(rs.next()){
                
                Vector v = new Vector();
                for(int i=1;i<=n;i++)
                {
                    v.add(rs.getInt("ProductID"));
                    v.add(rs.getString("ProductName"));
                    v.add(rs.getString("Category"));
                    v.add(rs.getInt("Quantity"));
                    v.add(rs.getInt("Price"));
                    v.add(rs.getString("Discription"));
                    v.add(rs.getBlob("Image"));
                    
                   
                    
                }
                    model.addRow(v);
           }
            
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void search(String str){
        
         model = (DefaultTableModel) jTable4.getModel();
         TableRowSorter<DefaultTableModel> trs = new TableRowSorter<>(model);
         jTable4.setRowSorter(trs);
         trs.setRowFilter(RowFilter.regexFilter(str));
    }
    public void search1(String str){
        
         model = (DefaultTableModel) jTable1.getModel();
         TableRowSorter<DefaultTableModel> trs = new TableRowSorter<>(model);
         jTable1.setRowSorter(trs);
         trs.setRowFilter(RowFilter.regexFilter(str));
    }
    public void search2(String str){
        
         model = (DefaultTableModel) jTable2.getModel();
         TableRowSorter<DefaultTableModel> trs = new TableRowSorter<>(model);
         jTable2.setRowSorter(trs);
         trs.setRowFilter(RowFilter.regexFilter(str));
    }
    public void search3(String str){
        
         model = (DefaultTableModel) jTable3.getModel();
         TableRowSorter<DefaultTableModel> trs = new TableRowSorter<>(model);
         jTable3.setRowSorter(trs);
         trs.setRowFilter(RowFilter.regexFilter(str));
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel23 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jTabbedPane3 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jComboBox1 = new javax.swing.JComboBox<>();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jTextField9 = new javax.swing.JTextField();
        jComboBox2 = new javax.swing.JComboBox<>();
        jTextField10 = new javax.swing.JTextField();
        jTextField11 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jTextField13 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField12 = new javax.swing.JTextField();
        jTextField14 = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jButton6 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel15 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel27 = new javax.swing.JLabel();
        Products = new javax.swing.JTextField();
        jButton15 = new javax.swing.JButton();
        jLabel28 = new javax.swing.JLabel();
        jTabbedPane4 = new javax.swing.JTabbedPane();
        jPanel5 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel29 = new javax.swing.JLabel();
        Orders = new javax.swing.JTextField();
        jButton17 = new javax.swing.JButton();
        jLabel30 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jTextField18 = new javax.swing.JTextField();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jTextField15 = new javax.swing.JTextField();
        jTextField16 = new javax.swing.JTextField();
        jTextField17 = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        jTabbedPane5 = new javax.swing.JTabbedPane();
        jPanel7 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        jTable3 = new javax.swing.JTable();
        Customer = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        jButton24 = new javax.swing.JButton();
        jLabel38 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        jTextField21 = new javax.swing.JTextField();
        jButton18 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jLabel35 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jTextField19 = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        jLabel32 = new javax.swing.JLabel();
        jTabbedPane6 = new javax.swing.JTabbedPane();
        jPanel9 = new javax.swing.JPanel();
        jPanel24 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        jLabel42 = new javax.swing.JLabel();
        jTextField23 = new javax.swing.JTextField();
        jButton26 = new javax.swing.JButton();
        jLabel43 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jLabel33 = new javax.swing.JLabel();
        jTextField22 = new javax.swing.JTextField();
        jButton20 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jButton22 = new javax.swing.JButton();
        jLabel37 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jTextField20 = new javax.swing.JTextField();
        jTextField24 = new javax.swing.JTextField();
        jScrollPane6 = new javax.swing.JScrollPane();
        jTextArea4 = new javax.swing.JTextArea();
        jLabel34 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTabbedPane1.setBackground(new java.awt.Color(204, 255, 255));
        jTabbedPane1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        jTabbedPane2.setBackground(new java.awt.Color(255, 204, 204));
        jTabbedPane2.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        jTabbedPane2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        jPanel23.setLayout(null);

        jLabel41.setIcon(new javax.swing.ImageIcon("C:\\Users\\sanjo\\Downloads\\ice-cream-img (3).jpg")); // NOI18N
        jPanel23.add(jLabel41);
        jLabel41.setBounds(4, 5, 680, 460);

        jTabbedPane2.addTab("Welcome", jPanel23);

        jTabbedPane1.addTab("Home", jTabbedPane2);
        jTabbedPane2.getAccessibleContext().setAccessibleName("Welcome");

        jTabbedPane3.setBackground(new java.awt.Color(204, 204, 255));
        jTabbedPane3.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        jTabbedPane3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jPanel11.setLayout(null);
        jPanel11.add(jTextField1);
        jTextField1.setBounds(140, 70, 170, 25);
        jPanel11.add(jTextField2);
        jTextField2.setBounds(140, 120, 170, 25);
        jPanel11.add(jTextField3);
        jTextField3.setBounds(140, 170, 170, 25);

        jComboBox1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Faluda", "Kulfi", "Rolled IceCream", "Mochi", "Softy", "Gelato", "Frozen Yogurt", "Snow Cream", "Stick IceCream" }));
        jPanel11.add(jComboBox1);
        jComboBox1.setBounds(140, 270, 170, 30);
        jPanel11.add(jTextField4);
        jTextField4.setBounds(420, 70, 170, 25);
        jPanel11.add(jTextField5);
        jTextField5.setBounds(420, 120, 170, 25);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jPanel11.add(jScrollPane1);
        jScrollPane1.setBounds(420, 170, 170, 80);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 255, 255));
        jLabel1.setText("Product ID :");
        jPanel11.add(jLabel1);
        jLabel1.setBounds(30, 70, 80, 20);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 255, 255));
        jLabel3.setText("Product Name :");
        jPanel11.add(jLabel3);
        jLabel3.setBounds(30, 120, 110, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(102, 255, 255));
        jLabel4.setText("Image :");
        jPanel11.add(jLabel4);
        jLabel4.setBounds(30, 170, 70, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(102, 255, 255));
        jLabel5.setText("Category Type : ");
        jPanel11.add(jLabel5);
        jLabel5.setBounds(30, 270, 111, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(102, 255, 255));
        jLabel6.setText("Quantity :");
        jPanel11.add(jLabel6);
        jLabel6.setBounds(320, 70, 70, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(102, 255, 255));
        jLabel7.setText("Price :");
        jPanel11.add(jLabel7);
        jLabel7.setBounds(320, 120, 60, 20);

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(102, 255, 255));
        jLabel8.setText("Description :");
        jPanel11.add(jLabel8);
        jLabel8.setBounds(320, 170, 100, 20);

        jButton1.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-add-product-24.png"))); // NOI18N
        jButton1.setText("Add Product");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton1);
        jButton1.setBounds(40, 360, 140, 30);

        jButton2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-erase-24_2.png"))); // NOI18N
        jButton2.setText("Clear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton2);
        jButton2.setBounds(200, 360, 100, 31);

        jButton11.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-add-file-24.png"))); // NOI18N
        jButton11.setText("Browse");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel11.add(jButton11);
        jButton11.setBounds(140, 210, 120, 30);

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\sanjo\\Downloads\\pexels-roman-odintsov-5061197.jpg")); // NOI18N
        jLabel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Add Product", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Script", 1, 14), new java.awt.Color(255, 255, 0))); // NOI18N
        jPanel11.add(jLabel2);
        jLabel2.setBounds(0, 0, 660, 440);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, 636, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, 435, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane3.addTab("Add Product", jPanel1);

        jPanel12.setLayout(null);
        jPanel12.add(jTextField7);
        jTextField7.setBounds(140, 70, 170, 25);
        jPanel12.add(jTextField8);
        jTextField8.setBounds(140, 120, 170, 25);
        jPanel12.add(jTextField9);
        jTextField9.setBounds(140, 170, 170, 25);

        jComboBox2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Faluda", "Kulfi", "Rolled IceCream", "Mochi", "Softy", "Gelato", "Frozen Yogurt", "Snow Cream", "Stick IceCream" }));
        jPanel12.add(jComboBox2);
        jComboBox2.setBounds(140, 260, 170, 30);
        jPanel12.add(jTextField10);
        jTextField10.setBounds(410, 70, 170, 25);
        jPanel12.add(jTextField11);
        jTextField11.setBounds(410, 120, 170, 25);

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        jPanel12.add(jScrollPane2);
        jScrollPane2.setBounds(410, 170, 170, 80);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 255, 255));
        jLabel9.setText("Product ID :");
        jPanel12.add(jLabel9);
        jLabel9.setBounds(30, 70, 80, 20);

        jLabel10.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(102, 255, 255));
        jLabel10.setText("Product Name :");
        jPanel12.add(jLabel10);
        jLabel10.setBounds(30, 120, 110, 20);

        jLabel11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(102, 255, 255));
        jLabel11.setText("Image :");
        jPanel12.add(jLabel11);
        jLabel11.setBounds(30, 170, 70, 20);

        jLabel12.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(102, 255, 255));
        jLabel12.setText("Category Type : ");
        jPanel12.add(jLabel12);
        jLabel12.setBounds(30, 260, 111, 20);

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(102, 255, 255));
        jLabel13.setText("Quantity :");
        jPanel12.add(jLabel13);
        jLabel13.setBounds(320, 70, 70, 20);

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(102, 255, 255));
        jLabel14.setText("Price :");
        jPanel12.add(jLabel14);
        jLabel14.setBounds(320, 120, 60, 20);

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(102, 255, 255));
        jLabel15.setText("Description :");
        jPanel12.add(jLabel15);
        jLabel15.setBounds(320, 170, 90, 20);

        jButton3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-update-24.png"))); // NOI18N
        jButton3.setText("Update ");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel12.add(jButton3);
        jButton3.setBounds(30, 330, 120, 31);

        jButton4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-erase-24_2.png"))); // NOI18N
        jButton4.setText("Clear");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel12.add(jButton4);
        jButton4.setBounds(180, 330, 100, 30);

        jButton5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-unpacking-24.png"))); // NOI18N
        jButton5.setText("Get Detail");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel12.add(jButton5);
        jButton5.setBounds(310, 330, 130, 30);

        jButton12.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-add-file-24.png"))); // NOI18N
        jButton12.setText("Browse");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton12ActionPerformed(evt);
            }
        });
        jPanel12.add(jButton12);
        jButton12.setBounds(140, 210, 110, 30);

        jLabel16.setIcon(new javax.swing.ImageIcon("C:\\Users\\sanjo\\Downloads\\pexels-roman-odintsov-5061197.jpg")); // NOI18N
        jLabel16.setText("Get ID");
        jLabel16.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Update Product", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Script", 1, 14), new java.awt.Color(255, 255, 0))); // NOI18N
        jPanel12.add(jLabel16);
        jLabel16.setBounds(0, 0, 630, 430);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, 616, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("Update Product", jPanel2);

        jPanel13.setLayout(null);
        jPanel13.add(jTextField13);
        jTextField13.setBounds(190, 80, 190, 25);
        jPanel13.add(jTextField6);
        jTextField6.setBounds(190, 140, 190, 25);
        jPanel13.add(jTextField12);
        jTextField12.setBounds(190, 190, 190, 25);

        jTextField14.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField14ActionPerformed(evt);
            }
        });
        jPanel13.add(jTextField14);
        jTextField14.setBounds(190, 250, 190, 25);

        jLabel17.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 255, 255));
        jLabel17.setText("Product ID :");
        jPanel13.add(jLabel17);
        jLabel17.setBounds(70, 80, 80, 20);

        jButton6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-bin-24.png"))); // NOI18N
        jButton6.setText("Delete");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel13.add(jButton6);
        jButton6.setBounds(70, 330, 110, 30);

        jButton8.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-unpacking-24.png"))); // NOI18N
        jButton8.setText("Get ProductID");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel13.add(jButton8);
        jButton8.setBounds(370, 330, 150, 30);

        jButton7.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-erase-24.png"))); // NOI18N
        jButton7.setText("Clear");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel13.add(jButton7);
        jButton7.setBounds(230, 330, 100, 30);

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(51, 255, 255));
        jLabel18.setText("ProductName : ");
        jPanel13.add(jLabel18);
        jLabel18.setBounds(70, 140, 110, 20);

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(51, 255, 255));
        jLabel19.setText("Discription : ");
        jPanel13.add(jLabel19);
        jLabel19.setBounds(70, 190, 100, 20);

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(51, 255, 255));
        jLabel20.setText("Category Type :");
        jPanel13.add(jLabel20);
        jLabel20.setBounds(70, 250, 110, 20);

        jLabel24.setIcon(new javax.swing.ImageIcon("C:\\Users\\sanjo\\Downloads\\pexels-roman-odintsov-5061197.jpg")); // NOI18N
        jLabel24.setText("Get ID");
        jLabel24.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Delete Product", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Script", 1, 14), new java.awt.Color(255, 255, 0))); // NOI18N
        jPanel13.add(jLabel24);
        jLabel24.setBounds(0, 0, 630, 440);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, 630, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, 435, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane3.addTab("Delete Product", jPanel4);

        jPanel16.setLayout(null);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "ProductID", "ProductName", "Category", "Quantity", "Price", "Description", "Image"
            }
        ));
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(jTable1);

        jPanel16.add(jScrollPane4);
        jScrollPane4.setBounds(10, 90, 620, 350);

        jLabel27.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-search-24.png"))); // NOI18N
        jLabel27.setText("Search Products : ");
        jPanel16.add(jLabel27);
        jLabel27.setBounds(50, 40, 160, 30);

        Products.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                ProductsKeyReleased(evt);
            }
        });
        jPanel16.add(Products);
        Products.setBounds(210, 40, 210, 30);

        jButton15.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-reset-23.png"))); // NOI18N
        jButton15.setText("Refresh");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton15ActionPerformed(evt);
            }
        });
        jPanel16.add(jButton15);
        jButton15.setBounds(470, 40, 110, 30);

        jLabel28.setBackground(new java.awt.Color(204, 255, 255));
        jLabel28.setForeground(new java.awt.Color(204, 255, 255));
        jLabel28.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "View IceCream", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Script", 0, 14), new java.awt.Color(255, 0, 255))); // NOI18N
        jLabel28.setIconTextGap(6);
        jPanel16.add(jLabel28);
        jLabel28.setBounds(0, 0, 650, 450);

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, 630, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, 435, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 642, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 447, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel15, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane3.addTab("View Product", jPanel3);

        jTabbedPane1.addTab("Product", jTabbedPane3);

        jTabbedPane4.setBackground(new java.awt.Color(153, 153, 255));
        jTabbedPane4.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        jTabbedPane4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jPanel18.setLayout(null);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "OrderID", "ProductID", "Quantity", "CustomerID", "Date", "PhoneNo", "Address"
            }
        ));
        jScrollPane5.setViewportView(jTable2);

        jPanel18.add(jScrollPane5);
        jScrollPane5.setBounds(10, 100, 640, 340);

        jLabel29.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-search-24.png"))); // NOI18N
        jLabel29.setText("Search Order : ");
        jPanel18.add(jLabel29);
        jLabel29.setBounds(50, 40, 140, 30);

        Orders.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                OrdersKeyReleased(evt);
            }
        });
        jPanel18.add(Orders);
        Orders.setBounds(210, 40, 210, 30);

        jButton17.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-reset-23.png"))); // NOI18N
        jButton17.setText("Refresh");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton17ActionPerformed(evt);
            }
        });
        jPanel18.add(jButton17);
        jButton17.setBounds(470, 40, 110, 30);

        jLabel30.setBackground(new java.awt.Color(204, 255, 255));
        jLabel30.setForeground(new java.awt.Color(204, 255, 255));
        jLabel30.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "View Orders", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Script", 0, 14), new java.awt.Color(255, 0, 255))); // NOI18N
        jLabel30.setIconTextGap(6);
        jPanel18.add(jLabel30);
        jLabel30.setBounds(0, 0, 670, 450);

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, 648, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, 435, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 660, Short.MAX_VALUE)
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 447, Short.MAX_VALUE)
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jTabbedPane4.addTab("View Orders", jPanel5);

        jPanel14.setLayout(null);

        jLabel26.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 51));
        jLabel26.setText("Order ID : ");
        jPanel14.add(jLabel26);
        jLabel26.setBounds(60, 90, 100, 30);
        jPanel14.add(jTextField18);
        jTextField18.setBounds(180, 90, 150, 30);

        jButton9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-bin-24.png"))); // NOI18N
        jButton9.setText("Delete");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel14.add(jButton9);
        jButton9.setBounds(60, 350, 110, 30);

        jButton10.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-unpacking-24.png"))); // NOI18N
        jButton10.setText("GetOrderDetail");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel14.add(jButton10);
        jButton10.setBounds(200, 350, 160, 30);

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 102));
        jLabel21.setText("ProductID :");
        jPanel14.add(jLabel21);
        jLabel21.setBounds(60, 150, 100, 30);

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 102));
        jLabel22.setText("CusromerID :");
        jPanel14.add(jLabel22);
        jLabel22.setBounds(60, 210, 100, 30);

        jLabel23.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 102));
        jLabel23.setText("Date :");
        jPanel14.add(jLabel23);
        jLabel23.setBounds(60, 270, 100, 30);
        jPanel14.add(jTextField15);
        jTextField15.setBounds(180, 150, 150, 30);

        jTextField16.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField16ActionPerformed(evt);
            }
        });
        jPanel14.add(jTextField16);
        jTextField16.setBounds(180, 210, 150, 30);
        jPanel14.add(jTextField17);
        jTextField17.setBounds(180, 270, 150, 30);

        jLabel25.setIcon(new javax.swing.ImageIcon("C:\\Users\\sanjo\\Downloads\\246-2468984_delete (2).jpg")); // NOI18N
        jLabel25.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Delete Order", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Script", 1, 14), new java.awt.Color(255, 51, 255))); // NOI18N
        jPanel14.add(jLabel25);
        jLabel25.setBounds(3, 0, 650, 440);

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, 654, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel14, javax.swing.GroupLayout.DEFAULT_SIZE, 441, Short.MAX_VALUE))
        );

        jTabbedPane4.addTab("Delete Order", jPanel6);

        jTabbedPane1.addTab("Orders", jTabbedPane4);

        jTabbedPane5.setBackground(new java.awt.Color(255, 153, 153));
        jTabbedPane5.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        jTabbedPane5.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jPanel21.setLayout(null);

        jTable3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "CustomerID", "CustomerName", "Date ", "Phone", "Address"
            }
        ));
        jScrollPane7.setViewportView(jTable3);

        jPanel21.add(jScrollPane7);
        jScrollPane7.setBounds(10, 90, 610, 350);

        Customer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CustomerActionPerformed(evt);
            }
        });
        Customer.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                CustomerKeyReleased(evt);
            }
        });
        jPanel21.add(Customer);
        Customer.setBounds(210, 40, 230, 30);

        jLabel39.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel39.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-search-24.png"))); // NOI18N
        jLabel39.setText("Search Customer :");
        jPanel21.add(jLabel39);
        jLabel39.setBounds(40, 40, 160, 30);

        jButton24.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton24.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-reset-23.png"))); // NOI18N
        jButton24.setText("Refresh");
        jButton24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton24ActionPerformed(evt);
            }
        });
        jPanel21.add(jButton24);
        jButton24.setBounds(490, 40, 110, 30);

        jLabel38.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "View Customer", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Script", 0, 14), new java.awt.Color(0, 0, 204))); // NOI18N
        jPanel21.add(jLabel38);
        jLabel38.setBounds(0, 0, 660, 450);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel21, javax.swing.GroupLayout.DEFAULT_SIZE, 630, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel21, javax.swing.GroupLayout.DEFAULT_SIZE, 441, Short.MAX_VALUE))
        );

        jTabbedPane5.addTab("View Customer", jPanel7);

        jPanel19.setLayout(null);

        jLabel31.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 51));
        jLabel31.setText("Customer ID : ");
        jPanel19.add(jLabel31);
        jLabel31.setBounds(40, 110, 120, 30);
        jPanel19.add(jTextField21);
        jTextField21.setBounds(170, 110, 150, 30);

        jButton18.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-bin-24.png"))); // NOI18N
        jButton18.setText("Delete");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });
        jPanel19.add(jButton18);
        jButton18.setBounds(60, 360, 110, 30);

        jButton19.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-unpacking-24.png"))); // NOI18N
        jButton19.setText("GetCustomerDetails");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });
        jPanel19.add(jButton19);
        jButton19.setBounds(200, 360, 200, 30);

        jLabel35.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel35.setForeground(new java.awt.Color(255, 255, 102));
        jLabel35.setText("CustomerName : ");
        jPanel19.add(jLabel35);
        jLabel35.setBounds(40, 170, 130, 20);

        jLabel36.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 102));
        jLabel36.setText("Address : ");
        jPanel19.add(jLabel36);
        jLabel36.setBounds(40, 220, 100, 30);
        jPanel19.add(jTextField19);
        jTextField19.setBounds(170, 170, 150, 30);

        jTextArea3.setColumns(20);
        jTextArea3.setRows(5);
        jScrollPane3.setViewportView(jTextArea3);

        jPanel19.add(jScrollPane3);
        jScrollPane3.setBounds(170, 230, 180, 80);

        jLabel32.setIcon(new javax.swing.ImageIcon("C:\\Users\\sanjo\\Downloads\\246-2468984_delete (2).jpg")); // NOI18N
        jLabel32.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Delete Customer", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Script", 0, 14), new java.awt.Color(255, 0, 255))); // NOI18N
        jPanel19.add(jLabel32);
        jLabel32.setBounds(3, 0, 640, 450);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel19, javax.swing.GroupLayout.DEFAULT_SIZE, 630, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel19, javax.swing.GroupLayout.DEFAULT_SIZE, 441, Short.MAX_VALUE))
        );

        jTabbedPane5.addTab("Delete Customer", jPanel8);

        jTabbedPane1.addTab("Customer", jTabbedPane5);

        jTabbedPane6.setBackground(new java.awt.Color(102, 255, 102));
        jTabbedPane6.setTabPlacement(javax.swing.JTabbedPane.LEFT);
        jTabbedPane6.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        jPanel24.setLayout(null);

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "CustomerID", "Date", "Rate", "Comment"
            }
        ));
        jScrollPane8.setViewportView(jTable4);

        jPanel24.add(jScrollPane8);
        jScrollPane8.setBounds(10, 90, 610, 340);

        jLabel42.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel42.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-search-24.png"))); // NOI18N
        jLabel42.setText("Search Feedback : ");
        jPanel24.add(jLabel42);
        jLabel42.setBounds(50, 40, 160, 30);

        jTextField23.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextField23KeyReleased(evt);
            }
        });
        jPanel24.add(jTextField23);
        jTextField23.setBounds(220, 40, 210, 30);

        jButton26.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-reset-23.png"))); // NOI18N
        jButton26.setText("Refresh");
        jButton26.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton26ActionPerformed(evt);
            }
        });
        jPanel24.add(jButton26);
        jButton26.setBounds(480, 40, 110, 30);

        jLabel43.setBackground(new java.awt.Color(204, 255, 255));
        jLabel43.setForeground(new java.awt.Color(204, 255, 255));
        jLabel43.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "View Feedback", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Script", 0, 14), new java.awt.Color(255, 0, 255))); // NOI18N
        jLabel43.setIconTextGap(6);
        jPanel24.add(jLabel43);
        jLabel43.setBounds(0, 0, 650, 450);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, 627, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel24, javax.swing.GroupLayout.DEFAULT_SIZE, 441, Short.MAX_VALUE))
        );

        jTabbedPane6.addTab("View Feedback", jPanel9);

        jPanel20.setLayout(null);

        jLabel33.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(51, 51, 255));
        jLabel33.setText("Customer ID : ");
        jPanel20.add(jLabel33);
        jLabel33.setBounds(60, 90, 110, 20);

        jTextField22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField22ActionPerformed(evt);
            }
        });
        jPanel20.add(jTextField22);
        jTextField22.setBounds(180, 90, 150, 25);

        jButton20.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-bin-24.png"))); // NOI18N
        jButton20.setText("Delete");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });
        jPanel20.add(jButton20);
        jButton20.setBounds(50, 360, 110, 30);

        jButton21.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButton21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-unpacking-24.png"))); // NOI18N
        jButton21.setText("GetDetails");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });
        jPanel20.add(jButton21);
        jButton21.setBounds(190, 360, 130, 30);

        jButton22.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-logout-24.png"))); // NOI18N
        jButton22.setText("Logout");
        jButton22.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton22ActionPerformed(evt);
            }
        });
        jPanel20.add(jButton22);
        jButton22.setBounds(350, 360, 120, 30);

        jLabel37.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(51, 51, 255));
        jLabel37.setText("Date :");
        jPanel20.add(jLabel37);
        jLabel37.setBounds(60, 140, 100, 25);

        jLabel40.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(51, 51, 255));
        jLabel40.setText("Rating :");
        jPanel20.add(jLabel40);
        jLabel40.setBounds(60, 190, 100, 25);

        jLabel44.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(51, 51, 255));
        jLabel44.setText("Comments :");
        jPanel20.add(jLabel44);
        jLabel44.setBounds(60, 240, 100, 25);
        jPanel20.add(jTextField20);
        jTextField20.setBounds(180, 140, 150, 25);

        jTextField24.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField24ActionPerformed(evt);
            }
        });
        jPanel20.add(jTextField24);
        jTextField24.setBounds(180, 190, 80, 25);

        jTextArea4.setColumns(20);
        jTextArea4.setRows(5);
        jScrollPane6.setViewportView(jTextArea4);

        jPanel20.add(jScrollPane6);
        jScrollPane6.setBounds(180, 250, 190, 70);

        jLabel34.setIcon(new javax.swing.ImageIcon("C:\\Users\\sanjo\\Downloads\\246-2468984_delete (2).jpg")); // NOI18N
        jLabel34.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Delete Feedback", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Script", 1, 14), new java.awt.Color(255, 51, 255))); // NOI18N
        jPanel20.add(jLabel34);
        jLabel34.setBounds(0, 0, 630, 440);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, 633, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, 441, Short.MAX_VALUE))
        );

        jTabbedPane6.addTab("Delete feedback", jPanel10);

        jTabbedPane1.addTab("Feedback And Logout", jTabbedPane6);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jTabbedPane1))
        );

        jTabbedPane1.getAccessibleContext().setAccessibleName("Home");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void CustomerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CustomerActionPerformed
        
    }//GEN-LAST:event_CustomerActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
         
         JFileChooser file = new JFileChooser();
         file.setCurrentDirectory(new File ("user.dir"));
         
         FileNameExtensionFilter filter = new  FileNameExtensionFilter("All pics","Png","jpg","jpeg");
         file.addChoosableFileFilter(filter);
         
         int a = file.showSaveDialog(null);
         if(a==JFileChooser.APPROVE_OPTION)
         {
           jTextField3.setText(file.getSelectedFile().getAbsolutePath());
         }
         
         
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField3.setText("");
        jTextField4.setText("");
        jTextField5.setText("");
        jTextArea1.setText("");
        
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
            jTextField7.setText("");
            jTextField8.setText("");
            jTextField9.setText("");
            jTextField10.setText("");
            jTextField11.setText("");
            jTextField11.setText("");
            jTextArea2.setText("");
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton12ActionPerformed
        
        JFileChooser file = new JFileChooser();
         file.setCurrentDirectory(new File ("user.dir"));
         
         FileNameExtensionFilter filter = new  FileNameExtensionFilter("All pics","Png","jpg","jpeg");
         file.addChoosableFileFilter(filter);
         
         int a = file.showSaveDialog(null);
         if(a==JFileChooser.APPROVE_OPTION)
         {
           jTextField9.setText(file.getSelectedFile().getAbsolutePath());
         }
    }//GEN-LAST:event_jButton12ActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
          
        
    }//GEN-LAST:event_jTable1MouseClicked

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       try
       {
        int pid =Integer.parseInt(jTextField1.getText());
        
        String pname = jTextField2.getText();
        int pqty =Integer.parseInt( jTextField4.getText());
        int price = Integer.parseInt(jTextField5.getText());
        String catg = (String) jComboBox1.getSelectedItem();
        String dcri = jTextArea1.getText();
        String img = jTextField3.getText();
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
        PreparedStatement ps =con.prepareStatement("insert into Product(ProductID,ProductName,Category,Quantity,Price,Discription,Image)value(?,?,?,?,?,?,?)");
        InputStream ia=null ;
           try {
               ia= new FileInputStream(img);
           } catch (FileNotFoundException ex) {
               Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
           }
        ps.setInt(1,pid);
        ps.setString(2,pname);
        ps.setString(3, catg);
        ps.setInt(4,pqty);
        ps.setInt(5,price); 
        ps.setString(6,dcri);
        ps.setBlob(7, ia);
        
        int row = ps.executeUpdate();
        if(row > 0)
        {
            JOptionPane.showMessageDialog(this,"Product Added Successfully");
        }
        else
        {
            JOptionPane.showMessageDialog(this,"Product not Added"); 
        } 
        
        
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton22ActionPerformed
        Login l = new Login();
        l.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton22ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        
        try
       {
        int pid =Integer.parseInt(jTextField7.getText());
        String pname = jTextField8.getText();
        int pqty =Integer.parseInt( jTextField10.getText());
        int price =Integer.parseInt( jTextField11.getText());
        String catg = (String) jComboBox2.getSelectedItem();
        String dcri = jTextArea2.getText();
        String img = jTextField9.getText();
        
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
        PreparedStatement ps =con.prepareStatement("Update product set ProductName=?,Category=?,Quantity=?,Price=?,Discription=?,Image=? where ProductID=?");
        
        InputStream ia=null ;
           try {
               ia= new FileInputStream(img);
           } catch (FileNotFoundException ex) {
               Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
           }
        
        ps.setString(1,pname);
        ps.setString(2, catg);
        ps.setInt(3,pqty);
        ps.setInt(4,price); 
        ps.setString(5,dcri);
        ps.setBlob(6, ia);
        ps.setInt(7,pid);
        
       
        int row = ps.executeUpdate();
        if(row > 0)
        {
            JOptionPane.showMessageDialog(this,"Product Update Successfully");
        }
        else
        {
            JOptionPane.showMessageDialog(this,"Product not Update"); 
        }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        
         try
       {
        int pid =Integer.parseInt( jTextField13.getText());
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
        PreparedStatement ps =con.prepareStatement("Delete From product where ProductID=?");
        
        ps.setInt(1,pid);
        
        int row = ps.executeUpdate();
        if(row > 0)
        {
            JOptionPane.showMessageDialog(this,"Product Delete Successfully");
        }
        else
        {
            JOptionPane.showMessageDialog(this,"Product not Deleted"); 
        }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        
         try
       {
        int pid = Integer.parseInt( jTextField21.getText());
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
        PreparedStatement ps =con.prepareStatement("Delete From Customer where UserID=?");
        
       ps.setInt(1,pid);
        
        int row = ps.executeUpdate();
        if(row > 0)
        {
            JOptionPane.showMessageDialog(this,"Customer Deleted Successfully");
        }
        else
        {
            JOptionPane.showMessageDialog(this,"Customer not Deleted"); 
        }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton18ActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
        
        try
       {
        int pid =Integer.parseInt (jTextField22.getText());
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
        PreparedStatement ps =con.prepareStatement("Delete From Customerfeedback where CustomerID=?");
        
       ps.setInt(1,pid);
        
        int row = ps.executeUpdate();
        if(row > 0)
        {
            JOptionPane.showMessageDialog(this,"Feedback Deleted Successfully");
        }
        else
        {
            JOptionPane.showMessageDialog(this,"Feedback not Deleted"); 
        }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton20ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        
        try
       {
        String pid = jTextField18.getText();
        
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
        PreparedStatement ps =con.prepareStatement("Delete From Orders where OrderID=?");
        
       ps.setString(1,pid);
        
        int row = ps.executeUpdate();
        if(row > 0)
        {
            JOptionPane.showMessageDialog(this,"Order Deleted Successfully");
        }
        else
        {
            JOptionPane.showMessageDialog(this,"Order not Deleted"); 
        }
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jTextField23KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextField23KeyReleased
        
        String str1=jTextField23.getText();
        search(str1);
    }//GEN-LAST:event_jTextField23KeyReleased

    private void ProductsKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_ProductsKeyReleased
        String str1=Products.getText();
        search1(str1);
    }//GEN-LAST:event_ProductsKeyReleased

    private void OrdersKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_OrdersKeyReleased
        String str1=Orders.getText();
        search2(str1);
    }//GEN-LAST:event_OrdersKeyReleased

    private void CustomerKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_CustomerKeyReleased
        String str1=Customer.getText();
        search3(str1);
    }//GEN-LAST:event_CustomerKeyReleased

    private void jButton26ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton26ActionPerformed
        
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            PreparedStatement ps = con.prepareStatement("Select * from Customerfeedback");
            ResultSet rs =ps.executeQuery();
            ResultSetMetaData rsmd=(ResultSetMetaData) rs.getMetaData();
            int n=rsmd.getColumnCount();
            model = (DefaultTableModel) jTable4.getModel();
            model.setRowCount(0);
            
            while(rs.next()){
                
                Vector v = new Vector();
                for(int i=1;i<=n;i++)
                {
                    v.add(rs.getString("CustomerID"));
                    v.add(rs.getString("Date"));
                    v.add(rs.getString("Rate"));
                    v.add(rs.getString("Comment"));
                   
                    
                }
                    model.addRow(v);
           }
            
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        jTable4.setAutoCreateRowSorter(true);
    }//GEN-LAST:event_jButton26ActionPerformed

    private void jButton24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton24ActionPerformed
        
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            PreparedStatement ps = con.prepareStatement("Select * from Customer");
            ResultSet rs =ps.executeQuery();
            ResultSetMetaData rsmd=(ResultSetMetaData) rs.getMetaData();
            int n=rsmd.getColumnCount();
            model = (DefaultTableModel) jTable3.getModel();
            model.setRowCount(0);
            
            while(rs.next()){
                
                Vector v = new Vector();
                for(int i=1;i<=n;i++)
                {
                    v.add(rs.getString("UserID"));
                    v.add(rs.getString("UserName"));
                    v.add(rs.getString("Date"));
                    v.add(rs.getString("Phone"));
                    v.add(rs.getString("Address"));
                   
                    
                }
                    model.addRow(v);
           }
            
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        jTable3.setAutoCreateRowSorter(true);
    }//GEN-LAST:event_jButton24ActionPerformed

    private void jButton17ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton17ActionPerformed
        
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            PreparedStatement ps = con.prepareStatement("Select * from orders");
            ResultSet rs =ps.executeQuery();
            ResultSetMetaData rsmd=(ResultSetMetaData) rs.getMetaData();
            int n=rsmd.getColumnCount();
            model = (DefaultTableModel) jTable2.getModel();
            model.setRowCount(0);
            
            while(rs.next()){
                
                Vector v = new Vector();
                for(int i=1;i<=n;i++)
                {
                    v.add(rs.getString("OrderID"));
                    v.add(rs.getString("ProductID"));
                    v.add(rs.getString("Quantity"));
                    v.add(rs.getString("CustomerID"));
                    v.add(rs.getString("Date"));
                    v.add(rs.getString("Phone"));
                    v.add(rs.getString("Address"));
                }
                    model.addRow(v);
           }
            
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        jTable2.setAutoCreateRowSorter(true);
    }//GEN-LAST:event_jButton17ActionPerformed

    private void jButton15ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton15ActionPerformed
        
         try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            PreparedStatement ps = con.prepareStatement("Select * from product");
            ResultSet rs =ps.executeQuery();
            ResultSetMetaData rsmd=(ResultSetMetaData) rs.getMetaData();
            int n=rsmd.getColumnCount();
            model = (DefaultTableModel) jTable1.getModel();
            model.setRowCount(0);
            
            while(rs.next()){
                
                Vector v = new Vector();
                for(int i=1;i<=n;i++)
                {
                    v.add(rs.getInt("ProductID"));
                    v.add(rs.getString("ProductName"));
                    v.add(rs.getString("Category"));
                    v.add(rs.getInt("Quantity"));
                    v.add(rs.getInt("Price"));
                    v.add(rs.getString("Discription"));
                    v.add(rs.getBlob("Image"));
                    
                   
                    
                }
                    model.addRow(v);
           }
            
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
        jTable1.setAutoCreateRowSorter(true);
    }//GEN-LAST:event_jButton15ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        
        String pid = jTextField13.getText();
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            Statement obj=(Statement) con.createStatement();
            ResultSet rs=obj.executeQuery("select ProductName,Discription,Category from Product where ProductID='"+pid+"';");
            if(rs.next()){
                
                jTextField6.setText(rs.getString(1));
                jTextField12.setText(rs.getString(2));
                jTextField14.setText(rs.getString(3));
                
                }
  
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jTextField14ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField14ActionPerformed
        
    }//GEN-LAST:event_jTextField14ActionPerformed

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
       
        jTextField6.setText("");
        jTextField12.setText("");
        jTextField13.setText("");
        jTextField14.setText("");
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
       
        int orid = Integer.parseInt( jTextField18.getText());
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            Statement obj=(Statement) con.createStatement();
            ResultSet rs=obj.executeQuery("select ProductID,CustomerID,Date from Orders where OrderID='"+orid+"';");
            if(rs.next()){
                
                jTextField15.setText(rs.getString(1));
                jTextField16.setText(rs.getString(2));
                jTextField17.setText(rs.getString(3));
                
                }
  
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jTextField16ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField16ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField16ActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
       
        int userid = Integer.parseInt( jTextField21.getText());
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            Statement obj=(Statement) con.createStatement();
            ResultSet rs=obj.executeQuery("select UserName,Address from Customer where UserID='"+userid+"';");
            if(rs.next()){
                
                jTextField19.setText(rs.getString(1));
                jTextArea3.setText(rs.getString(2));
                
                
                }
  
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton19ActionPerformed

    private void jTextField24ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField24ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField24ActionPerformed

    private void jTextField22ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField22ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField22ActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        
        int Custid = Integer.parseInt( jTextField22.getText());
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            Statement obj=(Statement) con.createStatement();
            ResultSet rs=obj.executeQuery("select Date,Rate,Comment from customerfeedback where CustomerID='"+Custid+"';");
            if(rs.next()){
                
                jTextField20.setText(rs.getString(1));
                jTextField24.setText(rs.getString(2));
                jTextArea4.setText(rs.getString(3));
                
                
                }
  
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton21ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        
        int pid = Integer.parseInt( jTextField7.getText());
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con =DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
            Statement obj=(Statement) con.createStatement();
            ResultSet rs=obj.executeQuery("select ProductName,Category,Quantity,Price,Discription,Image from Product where ProductID='"+pid+"';");
            if(rs.next()){
                
                jTextField8.setText(rs.getString(1));
                jComboBox2.setSelectedItem(rs.getString(2));
                jTextField10.setText(rs.getString(3));
                jTextField11.setText(rs.getString(4));
                jTextArea2.setText(rs.getString(5));
                jTextField9.setText(rs.getString(6));
                
                
                
                }
  
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(AdminPanel.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton5ActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(() -> {
            new AdminPanel().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Customer;
    private javax.swing.JTextField Orders;
    private javax.swing.JTextField Products;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton26;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTabbedPane jTabbedPane3;
    private javax.swing.JTabbedPane jTabbedPane4;
    private javax.swing.JTabbedPane jTabbedPane5;
    private javax.swing.JTabbedPane jTabbedPane6;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable3;
    private javax.swing.JTable jTable4;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextArea jTextArea4;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField14;
    private javax.swing.JTextField jTextField15;
    private javax.swing.JTextField jTextField16;
    private javax.swing.JTextField jTextField17;
    private javax.swing.JTextField jTextField18;
    private javax.swing.JTextField jTextField19;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField20;
    private javax.swing.JTextField jTextField21;
    private javax.swing.JTextField jTextField22;
    private javax.swing.JTextField jTextField23;
    private javax.swing.JTextField jTextField24;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration//GEN-END:variables
}
