package com.mycompany.mavenproject2;

import java.awt.HeadlessException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */

/**
 *
 * @author sanjo
 */
public class Login extends javax.swing.JFrame {

   
    public Login() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jTextField1 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 0));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-user-30.png"))); // NOI18N
        jLabel2.setText(" UserName :");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(40, 120, 120, 40);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 0));
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-key-24.png"))); // NOI18N
        jLabel3.setText("  Password :");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(40, 170, 130, 40);

        jLabel4.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 51, 255));
        jLabel4.setText("Login");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(250, 20, 90, 40);

        jRadioButton1.setBackground(new java.awt.Color(0, 0, 0));
        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jRadioButton1.setForeground(new java.awt.Color(255, 255, 51));
        jRadioButton1.setText("Admin");
        jRadioButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jRadioButton1);
        jRadioButton1.setBounds(50, 80, 80, 25);

        jRadioButton2.setBackground(new java.awt.Color(0, 0, 0));
        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jRadioButton2.setForeground(new java.awt.Color(255, 255, 51));
        jRadioButton2.setText("Customer");
        jPanel1.add(jRadioButton2);
        jRadioButton2.setBounds(170, 80, 90, 25);
        jPanel1.add(jTextField1);
        jTextField1.setBounds(170, 130, 170, 25);
        jPanel1.add(jPasswordField1);
        jPasswordField1.setBounds(170, 180, 170, 25);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-enter-24.png"))); // NOI18N
        jButton1.setText("Login");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(40, 240, 110, 30);

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-registration-24.png"))); // NOI18N
        jButton3.setText("Register");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton3);
        jButton3.setBounds(170, 240, 120, 30);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\sanjo\\Downloads\\pexels-roman-odintsov-5061214 (1).jpg")); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 580, 340);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 571, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 330, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jRadioButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButton1ActionPerformed
        
        
       
    }//GEN-LAST:event_jRadioButton1ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        
       Registration rs = new Registration();
                rs.setVisible(true);
                this.dispose();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        String UserName= jTextField1.getText();
        String Password= String.valueOf(jPasswordField1.getPassword());
        if(jRadioButton1.isSelected())
        {
        try
        {
           Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root")) {
                Statement obj=(Statement) con.createStatement();
                ResultSet rs=obj.executeQuery("select * from Admin where UserName='"+UserName+"' and Password='"+Password+"';");
                if(rs.next()){
                    JOptionPane.showMessageDialog(this,"Login Successful","Success",JOptionPane.INFORMATION_MESSAGE);
                    AdminPanel ap = new AdminPanel();
                    ap.setVisible(true);
                    this.dispose();
                }
                else if(UserName.isEmpty() || Password.isEmpty()){
                    JOptionPane.showMessageDialog(this,"username and password cannot be empty","Error",JOptionPane.ERROR_MESSAGE);
                }
                else
                {
                    JOptionPane.showMessageDialog(this,"Invalid Credentials","Error",JOptionPane.ERROR_MESSAGE);
                }
            }
        }catch(HeadlessException | ClassNotFoundException | SQLException e){JOptionPane.showMessageDialog(this,e.getMessage());}
        }
        else if(jRadioButton2.isSelected())
        {
        try
        {
           Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root")) {
                Statement obj=(Statement) con.createStatement();
                ResultSet rs=obj.executeQuery("select * from Customer where UserName='"+UserName+"' and Password='"+Password+"';");
                if(rs.next()){
                    JOptionPane.showMessageDialog(this,"Login Successful","Success",JOptionPane.INFORMATION_MESSAGE);
                    CustomerPanel Cp = new CustomerPanel();
                    Cp.setVisible(true);
                    this.dispose();
                }
                else if(UserName.isEmpty() || Password.isEmpty()){
                    JOptionPane.showMessageDialog(this,"username and password cannot be empty","Error",JOptionPane.ERROR_MESSAGE);
                }
                else
                {
                    JOptionPane.showMessageDialog(this,"Invalid Credentials","Error",JOptionPane.ERROR_MESSAGE);
                }
            }
        }catch(HeadlessException | ClassNotFoundException | SQLException e){JOptionPane.showMessageDialog(this,e.getMessage());}
        } 
         else
        {
            JOptionPane.showMessageDialog(this, "Please select user");
        }
            
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(() -> {
            new Login().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
