/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.mycompany.mavenproject2;

import java.util.logging.Level;
import java.util.logging.Logger;

public final class Welcome extends javax.swing.JFrame {

    public Welcome() {
        initComponents();
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jProgressBar1 = new javax.swing.JProgressBar();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setName("Home"); // NOI18N

        jPanel1.setLayout(null);

        jProgressBar1.setBackground(new java.awt.Color(255, 255, 255));
        jProgressBar1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jProgressBar1.setForeground(new java.awt.Color(51, 51, 255));
        jProgressBar1.setStringPainted(true);
        jPanel1.add(jProgressBar1);
        jProgressBar1.setBounds(40, 240, 520, 20);

        jLabel2.setBackground(new java.awt.Color(51, 255, 255));
        jLabel2.setFont(new java.awt.Font("Segoe Script", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 0));
        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-ice-cream-shop-64.png"))); // NOI18N
        jPanel1.add(jLabel2);
        jLabel2.setBounds(30, 20, 80, 70);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Loading");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(40, 200, 100, 25);

        jLabel3.setBackground(java.awt.Color.magenta);
        jLabel3.setFont(new java.awt.Font("Bernard MT Condensed", 1, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 255, 255));
        jLabel3.setText("Welcome To The IceCream Shop");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(120, 50, 340, 40);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\sanjo\\Downloads\\9GjtjIj (5).jpg")); // NOI18N
        jLabel1.setText("  ");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 600, 330);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 330, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        
        Welcome wel = new Welcome();
        wel.setVisible(true);
        
        Login l = new Login();
        
             try
            {
                for(int i=1;i<=100;i++)
                {
               Thread.sleep(80);
               jProgressBar1.setValue(i);
               
               if(i%2==0)
               {
                   Welcome.jLabel4.setText("Loading..");
               }
               else
               {
                   Welcome.jLabel4.setText("Loading...");
               }
               
            }
            }catch(InterruptedException ex)
            {Logger.getLogger(Welcome.class.getName()).log(Level.SEVERE, null, ex);}
        
           wel.setVisible(true);
           l.setVisible(true);
           
           wel.dispose();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    public static javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    public static javax.swing.JProgressBar jProgressBar1;
    // End of variables declaration//GEN-END:variables
}
