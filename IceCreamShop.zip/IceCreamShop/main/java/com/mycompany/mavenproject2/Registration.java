package com.mycompany.mavenproject2;

import java.sql.*;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;





public class Registration extends javax.swing.JFrame {

    public void getdata() {

            }


    public Registration() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jDatePickerUtil1 = new org.jdatepicker.util.JDatePickerUtil();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jPasswordField1 = new javax.swing.JPasswordField();
        jTextField5 = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 255, 255));
        jLabel2.setText("User ID :");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(30, 90, 110, 20);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 255, 255));
        jLabel3.setText("User Name :");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(30, 150, 120, 20);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 255, 255));
        jLabel4.setText("Address :");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(30, 210, 90, 20);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 255, 255));
        jLabel5.setText("Date : ");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(340, 90, 50, 20);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 255, 255));
        jLabel6.setText("Phone :");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(340, 150, 60, 20);

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(102, 255, 255));
        jLabel7.setText("Password : ");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(340, 210, 90, 20);

        jLabel8.setFont(new java.awt.Font("Segoe Script", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(51, 255, 255));
        jLabel8.setText("REGISTER");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(270, 20, 160, 40);

        jTextField1.setBorder(javax.swing.BorderFactory.createCompoundBorder());
        jPanel1.add(jTextField1);
        jTextField1.setBounds(150, 90, 170, 23);
        jPanel1.add(jTextField2);
        jTextField2.setBounds(150, 150, 170, 23);
        jPanel1.add(jPasswordField1);
        jPasswordField1.setBounds(430, 210, 170, 23);

        jTextField5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField5ActionPerformed(evt);
            }
        });
        jPanel1.add(jTextField5);
        jTextField5.setBounds(430, 150, 170, 23);

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(150, 210, 170, 90);

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-submit-for-approval-24.png"))); // NOI18N
        jButton1.setText("Submit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(30, 370, 110, 30);

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icons8-erase-24.png"))); // NOI18N
        jButton2.setText("Clear");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2);
        jButton2.setBounds(160, 370, 100, 30);

        jRadioButton1.setBackground(new java.awt.Color(0, 0, 0));
        buttonGroup1.add(jRadioButton1);
        jRadioButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jRadioButton1.setForeground(new java.awt.Color(51, 255, 255));
        jRadioButton1.setText("Admin");
        jRadioButton1.setBorder(null);
        jPanel1.add(jRadioButton1);
        jRadioButton1.setBounds(30, 320, 80, 22);

        jRadioButton2.setBackground(new java.awt.Color(0, 0, 0));
        buttonGroup1.add(jRadioButton2);
        jRadioButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jRadioButton2.setForeground(new java.awt.Color(51, 255, 255));
        jRadioButton2.setText("Customer");
        jRadioButton2.setBorder(null);
        jPanel1.add(jRadioButton2);
        jRadioButton2.setBounds(140, 320, 90, 22);

        jDateChooser1.setDateFormatString("yyyy-MM-dd");
        jPanel1.add(jDateChooser1);
        jDateChooser1.setBounds(430, 90, 170, 23);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\sanjo\\Downloads\\pexels-rawan-jo-2677814.jpg")); // NOI18N
        jLabel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Welcome", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe Script", 1, 14), new java.awt.Color(255, 255, 0))); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(0, 0, 640, 440);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 644, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 442, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       
        
        String UserID = jTextField1.getText();
        String UserName = jTextField2.getText();
        String Password = String.valueOf(jPasswordField1.getPassword());
        String Address = jTextArea1.getText();
        Date date =jDateChooser1.getDate(); 
        SimpleDateFormat odf = new SimpleDateFormat("yyyy-MM-dd");
        String ddate =odf.format(date);
        String Phone = jTextField5.getText();
        
//        DateTimeFormatter date1 = DateTimeFormatter.ofPattern("yyyy-MM-dd");
//        LocalDateTime now = LocalDateTime.now();
//        jDateChooser1.setDate(date1.format(now));
        
        if(jRadioButton1.isSelected())
        {
        try
        {
        
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
                PreparedStatement ps =con.prepareStatement("insert into Admin(UserID,UserName,Password,Address,Date,Phone)value(?,?,?,?,?,?)");
        
            ps.setString(1,UserID);
            ps.setString(2,UserName);
            ps.setString(3, Password);
            ps.setString(4,Address);
            ps.setString(5,ddate); 
            ps.setString(6,Phone);

        int row = ps.executeUpdate();
        if(row > 0){
            JOptionPane.showMessageDialog(this, "Registration Successfull");
        }
        else if(UserID.isEmpty() || UserName.isEmpty() || Password.isEmpty()|| Address.isEmpty()|| ddate.isEmpty()|| Phone.isEmpty()){
                    JOptionPane.showMessageDialog(this," cannot be empty","Error",JOptionPane.ERROR_MESSAGE);
                }
        else {
            JOptionPane.showMessageDialog(this, "Registration  Unsuccessfull");
        }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
        }
        else if(jRadioButton2.isSelected())
        {
          try
        {
        
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/icecreamshop", "root", "root");
                PreparedStatement ps =con.prepareStatement("insert into Customer(UserID,UserName,Password,Address,Date,Phone)value(?,?,?,?,?,?)");
        
            ps.setString(1,UserID);
            ps.setString(2,UserName);
            ps.setString(3, Password);
            ps.setString(4,Address);
            ps.setString(5,ddate); 
            ps.setString(6,Phone);

        int row = ps.executeUpdate();
        if(row > 0){
            JOptionPane.showMessageDialog(this, "Registration Successfull");
        } else {
            JOptionPane.showMessageDialog(this, "Registration  Unsuccessfull");
        }
        }catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }  
        }
        else
        {
            JOptionPane.showMessageDialog(this, "Please select user");
        }
        
    

        Login l = new Login();
        l.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
        jTextField1.setText("");
        jTextField2.setText("");
        jTextField5.setText("");
        jTextArea1.setText("");
        jPasswordField1.setText("");
        jDateChooser1.setDate(null);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jTextField5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField5ActionPerformed
       
        String Phone=jTextField5.getText();
      
        if(!Pattern.matches("^[0-9]",Phone))
        {
           JOptionPane.showMessageDialog(this, "Please Enter Valid Number");         
            
        }
    }//GEN-LAST:event_jTextField5ActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registration().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private org.jdatepicker.util.JDatePickerUtil jDatePickerUtil1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField5;
    // End of variables declaration//GEN-END:variables
}
